//
//  UpdateProfileViewController.h
//  MOYA
//
//  Created by Simran on 12/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateProfileViewController : UIViewController
@property(nonatomic,strong)UIView *backgroundView;
@property(nonatomic,strong)UIView *changePasswordView;
@end
