//
//  UpdateProfileViewController.m
//  MOYA
//
//  Created by Simran on 12/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import "UpdateProfileViewController.h"
#import "MainViewController.h"
@interface UpdateProfileViewController ()

@end

@implementation UpdateProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupForChangePasswordView];
    
}

-(void)setupForChangePasswordView{
    
    self.backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    self.backgroundView.backgroundColor=[UIColor blackColor];
    self.backgroundView.alpha=0.7;
    [self.view addSubview:self.backgroundView];
    [self.backgroundView setHidden:YES];
    
    self.changePasswordView=[[UIView alloc]initWithFrame:CGRectMake(10,self.view.center.y-175, self.view.frame.size.width-20, 350)];
    self.changePasswordView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.changePasswordView];
    [self.changePasswordView setHidden:YES];
    
    
    UILabel *titleLbl=[[UILabel alloc]initWithFrame:CGRectMake(self.changePasswordView.center.x-100, 15,200, 30)];
    titleLbl.textAlignment = NSTextAlignmentCenter;
    titleLbl.textColor=[UIColor colorWithRed:0/255.0 green:164/255.0 blue:204/255.0 alpha:1.0];
    [titleLbl setFont:[UIFont fontWithName:@"Avenir-Heavy" size:21]];
    titleLbl.text=@"Password Update";
    [self.changePasswordView addSubview:titleLbl];
    
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(titleLbl.frame.origin.x-25, 17, 25,25)];
    imageView.image=[UIImage imageNamed:@"img_changepassword"];
    [self.changePasswordView addSubview:imageView];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0,titleLbl.frame.origin.y+40,self.changePasswordView.frame.size.width, 1)];
    lineView.backgroundColor=[UIColor colorWithRed:0/255.0 green:164/255.0 blue:204/255.0 alpha:1.0];
    [self.changePasswordView addSubview:lineView];
    
    for (int i=0; i<3; i++) {
    
    UIImageView *passwordChangeicon=[[UIImageView alloc]initWithFrame:CGRectMake(8, lineView.frame.origin.y+30+65*i, 25,25)];
    passwordChangeicon.image=[UIImage imageNamed:@"img_changepwd"];
    [self.changePasswordView addSubview:passwordChangeicon];
    
    }
    UITextField *oldPasswordTextF=[[UITextField alloc]initWithFrame:CGRectMake(35, lineView.frame.origin.y+20,self.changePasswordView.frame.size.width-50, 50)];
    oldPasswordTextF.backgroundColor=[UIColor whiteColor];
    oldPasswordTextF.placeholder=@"Old Password";
    oldPasswordTextF.layer.borderColor=[UIColor lightGrayColor].CGColor;
    oldPasswordTextF.textAlignment=NSTextAlignmentCenter;
    oldPasswordTextF.layer.borderWidth=1;
    [self.changePasswordView addSubview:oldPasswordTextF];
    
    UITextField *newPasswordTextF=[[UITextField alloc]initWithFrame:CGRectMake(35, oldPasswordTextF.frame.origin.y+oldPasswordTextF.frame.size.height+15,self.changePasswordView.frame.size.width-50, 50)];
    newPasswordTextF.backgroundColor=[UIColor whiteColor];
    newPasswordTextF.placeholder=@"New Password";
    newPasswordTextF.layer.borderColor=[UIColor lightGrayColor].CGColor;
    newPasswordTextF.textAlignment=NSTextAlignmentCenter;
    newPasswordTextF.layer.borderWidth=1;
    [self.changePasswordView addSubview:newPasswordTextF];
    
    UITextField *confirmPasswordTextF=[[UITextField alloc]initWithFrame:CGRectMake(35, newPasswordTextF.frame.origin.y+newPasswordTextF.frame.size.height+15,self.changePasswordView.frame.size.width-50, 50)];
    confirmPasswordTextF.backgroundColor=[UIColor whiteColor];
    confirmPasswordTextF.placeholder=@"Confirm Password";
    confirmPasswordTextF.layer.borderColor=[UIColor lightGrayColor].CGColor;
    confirmPasswordTextF.textAlignment=NSTextAlignmentCenter;
    confirmPasswordTextF.layer.borderWidth=1;
    [self.changePasswordView addSubview:confirmPasswordTextF];
    
    
    
    UIView *buttonsBackV=[[UIView alloc]initWithFrame:CGRectMake(0, self.changePasswordView.frame.size.height-70,self.changePasswordView.frame.size.width, 70)];
    buttonsBackV.backgroundColor=[UIColor colorWithRed:0/255.0 green:164/255.0 blue:204/255.0 alpha:1.0];
    [self.changePasswordView addSubview:buttonsBackV];
    
    UIButton *cancelButton=[[UIButton alloc]initWithFrame:CGRectMake(30,30, 100, 14)];
    [cancelButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [cancelButton setTitle:@"CANCEL" forState:UIControlStateNormal];
    [buttonsBackV addSubview: cancelButton];
    cancelButton.titleLabel.font=[UIFont fontWithName:@"Avenir-light" size:21];
    [cancelButton addTarget:self action:@selector(cancelChangePasswordView) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *updateButton=[[UIButton alloc]initWithFrame:CGRectMake(buttonsBackV.frame.size.width-130, 30, 100, 14)];
    updateButton.titleLabel.textColor=[UIColor whiteColor];
    [updateButton setTitle:@"UPDATE" forState:UIControlStateNormal];
    updateButton.titleLabel.font=[UIFont fontWithName:@"Avenir-light" size:21];
    [buttonsBackV addSubview: updateButton];
    
    
}
-(void)cancelChangePasswordView{
    
    [self.changePasswordView setHidden:YES];
    [self.backgroundView setHidden:YES];
}

-(IBAction)changePassword:(id)sender{
    
    [self.changePasswordView setHidden:NO];
    [self.backgroundView setHidden:NO];

}

-(IBAction)back:(id)sender{
    
  
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
    [self presentViewController:vc animated:NO completion:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
}



@end
