//
//  CheckoutViewController.h
//  MOYA
//
//  Created by Simran on 13/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckoutViewController : UIViewController
@property(nonatomic,strong)IBOutlet UIView *deliveryAddressBackV;
@property(nonatomic,strong)IBOutlet UIView *deliveryTimeBackV;
@end
