//
//  MainViewController.m
//  MOYA
//
//  Created by Simran on 12/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import "MainViewController.h"
#import "MainTableViewCell.h"
#import "CheckoutViewController.h"
@interface MainViewController ()
{
    UIScrollView *sideBarScrollV;
}
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.dataSource=self;
    self.tableView.delegate=self;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    self.tableView.showsVerticalScrollIndicator=NO;
    
    [self setUpOfSideBar];
  
}
//Side bar setup Start
-(void)setUpOfSideBar{
    
    self.sideBarButton.tag=0;
    
    //adding time slot pickup view background light view
    self.backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0,72, self.view.frame.size.width, self.view.frame.size.height+200)];
    self.backgroundView.backgroundColor=[UIColor blackColor];
    self.backgroundView.alpha=0.5;
    [self.view addSubview:self.backgroundView];
    [self.backgroundView setHidden:YES];
    
    //adding sidebar main backV
    
    self.sideBarBackV=[[UIView alloc]initWithFrame:CGRectMake(0,72, 0, self.view.frame.size.height)];
    self.sideBarBackV.backgroundColor=[UIColor colorWithRed:242/255.0 green:242/255.0 blue:242/255.0 alpha:1.0];
    self.sideBarBackV.clipsToBounds = YES;
    [self.view addSubview:self.sideBarBackV];
    [self.navigationController.view bringSubviewToFront:self.sideBarBackV];
    
    sideBarScrollV=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width-60, self.view.frame.size.height)];
    sideBarScrollV.showsVerticalScrollIndicator=NO;
    sideBarScrollV.contentSize = CGSizeMake(0,sideBarScrollV.frame.size.height+70);
    sideBarScrollV.backgroundColor=[UIColor clearColor];
    sideBarScrollV.backgroundColor=[UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1.0];
    self.sideBarBackV.clipsToBounds = YES;
    [self.sideBarBackV addSubview:sideBarScrollV];
    
    //adding view for sidebar buttons
    UIView *backV=[[UIView alloc]initWithFrame:CGRectMake(0, 150,self.view.frame.size.width-100,sideBarScrollV.frame.size.height-150)];
    backV.backgroundColor=[UIColor whiteColor];
  //  [sideBarScrollV addSubview:backV];
    
    NSArray *buttonsTitleArray=[[NSArray alloc]initWithObjects:@"PLACE AN ORDER",@"ORDERS",@"MY ACCOUNT",@"FEEDBACK",@"LOGOUT", nil];
    NSArray *buttonsIconArray=[[NSArray alloc]initWithObjects:@"img_preorder",@"img_order",@"img_profile",@"img_feedback",@"img_logout", nil];
    
    for (int i=0; i<5;i++) {
        
        UIView *lineV=[[UIView alloc]initWithFrame:CGRectMake(0, 180+80*i,sideBarScrollV.frame.size.width,2)];
        lineV.alpha=0.3;
        lineV.backgroundColor=[UIColor lightGrayColor];
        [sideBarScrollV addSubview:lineV];
        
        UILabel *buttonTitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(60, 210+80*i, 150, 20)];
        buttonTitleLabel.text=[buttonsTitleArray objectAtIndex:i];
        buttonTitleLabel.textColor=[UIColor darkGrayColor];
        [sideBarScrollV addSubview:buttonTitleLabel];

        UIImageView *iconImageV=[[UIImageView alloc]initWithFrame:CGRectMake(25, 209+80*i, 23, 23)];
      iconImageV.image=[UIImage imageNamed:[buttonsIconArray objectAtIndex:i]];
        
        [sideBarScrollV addSubview:iconImageV];
        UIButton *barButtons=[[UIButton alloc]initWithFrame:CGRectMake(60, 210+80*i, 150, 20)];
       // [barButtons setTitle:[buttonsTitleArray objectAtIndex:i] forState:UIControlStateNormal];
        [barButtons setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
        [backV addSubview:barButtons];
    }
    
     
    
    // setGestures on view
    
   UISwipeGestureRecognizer *swipeleft=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeleft:)];
    swipeleft.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:swipeleft];
    
   UISwipeGestureRecognizer *swiperight=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swiperight:)];
    swiperight.direction=UISwipeGestureRecognizerDirectionRight;
     [self.view addGestureRecognizer:swiperight];
    
    
}

-(void)setupOfUserImageVandNamelbl{
    
    //adding user imageView
    
    UIImageView *userImageV=[[UIImageView alloc]initWithFrame:CGRectMake(self.sideBarBackV.center.x-25, 45,50,50)];
    userImageV.backgroundColor=[UIColor whiteColor];
    userImageV.image=[UIImage imageNamed:@"img_noimage"];
    userImageV.layer.cornerRadius=userImageV.frame.size.height/2;
    [sideBarScrollV addSubview:userImageV];
    
    //adding label for user name
    
    UILabel *userNameLabel=[[UILabel alloc]initWithFrame:CGRectMake(self.sideBarBackV.center.x-75, userImageV.frame.origin.y+userImageV.frame.size.height+15, 150, 20)];
    userNameLabel.text=@"Yugal kishore";
    userNameLabel.textAlignment=NSTextAlignmentCenter;
    userNameLabel.textColor=[UIColor blackColor];
    [sideBarScrollV addSubview:userNameLabel];
}

-(void)swipeleft:(UISwipeGestureRecognizer*)gestureRecognizer
{
    
    //animate left gesture on view
    
    [UIView animateWithDuration:0.20
                          delay:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState|UIViewAnimationOptionTransitionFlipFromLeft
                     animations:^{
                         [self.backgroundView setHidden:YES];
                         [self.sideBarBackV setFrame:CGRectMake(0, 72, 0, self.view.frame.size.height)];
                         [self.sideBarButton setTag:0];
                         NSLog(@"left");
                         
                     }
                     completion:nil];
}


-(void)swiperight:(UISwipeGestureRecognizer*)gestureRecognizer
{
    
    //animate right gesture on view
    
    [UIView animateWithDuration:0.20
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut | UIViewAnimationOptionAllowUserInteraction
                     animations:^{
                         [self.backgroundView setHidden:NO];
                         [self.sideBarBackV setFrame:CGRectMake(0,72, self.view.frame.size.width-100, self.view.frame.size.height)];
                         [self setupOfUserImageVandNamelbl];
                         [self.sideBarButton setTag:1];
                         
                     }
                     completion:nil];
    
}
-(IBAction)sideBarAction:(id)sender{
    
    
    [UIView animateWithDuration:0.20  delay:0.0 options:UIViewAnimationOptionBeginFromCurrentState|
     UIViewAnimationOptionTransitionFlipFromLeft
                     animations:^{
                         if ([sender tag]==0) {
                            
                             [self.backgroundView setHidden:NO];
                             [self.sideBarBackV setFrame:CGRectMake(0, 72, self.view.frame.size.width-100, self.view.frame.size.height)];
                             [self setupOfUserImageVandNamelbl];
                             NSLog(@"tag0");
                             [self.sideBarButton setTag:1];
                             
                         }
                         
                         else{
                             [self.backgroundView setHidden:YES];
                             [self.sideBarBackV setFrame:CGRectMake(0,72,0, self.view.frame.size.height)];
                             self.sideBarButton.tag=0;
                             NSLog(@"tag1");
                         }
                         
                     }
                     completion:nil];
    
}

-(IBAction)proceedToOrder:(id)sender{
    
    
    CheckoutViewController* checkoutViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CheckoutViewController"];
    [self.navigationController pushViewController:checkoutViewController animated:YES];
    
}
#pragma tableViewMethods

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    return 143;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid=@"MainTableViewCell";
    MainTableViewCell* cell = (MainTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellid];
    if (cell==nil) {
        NSArray *nib = [[NSBundle mainBundle]loadNibNamed:@"MainTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.noOfUnitsTextF.delegate=self;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    
    
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
