//
//  LoginViewController.m
//  MOYA
//
//  Created by Simran on 11/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import "LoginViewController.h"
#import "SignUpViewController.h"
#import "UpdateProfileViewController.h"
@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupForForgotPasswordView];
   
}
-(void)setupForForgotPasswordView{
    
    self.backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    self.backgroundView.backgroundColor=[UIColor blackColor];
    self.backgroundView.alpha=0.7;
    [self.view addSubview:self.backgroundView];
    [self.backgroundView setHidden:YES];
    
    self.forgotPasswordView=[[UIView alloc]initWithFrame:CGRectMake(10,self.view.center.y-125, self.view.frame.size.width-10, 250)];
    self.forgotPasswordView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.forgotPasswordView];
    [self.forgotPasswordView setHidden:YES];
    
    
    UILabel *titleLbl=[[UILabel alloc]initWithFrame:CGRectMake(self.forgotPasswordView.center.x-100, 15,200, 30)];
    titleLbl.textAlignment = NSTextAlignmentCenter;
    titleLbl.textColor=[UIColor colorWithRed:0/255.0 green:164/255.0 blue:204/255.0 alpha:1.0];
    [titleLbl setFont:[UIFont fontWithName:@"Avenir-light" size:18]];
    titleLbl.text=@"FORGOT PASSWORD";
    [self.forgotPasswordView addSubview:titleLbl];
    
    UIImageView *imageView=[[UIImageView alloc]initWithFrame:CGRectMake(titleLbl.frame.origin.x-15, 20, 20,20)];
    imageView.image=[UIImage imageNamed:@"img_forgot"];
    [self.forgotPasswordView addSubview:imageView];
    
    UIView *lineView=[[UIView alloc]initWithFrame:CGRectMake(0,titleLbl.frame.origin.y+40,self.forgotPasswordView.frame.size.width, 1)];
    lineView.backgroundColor=[UIColor colorWithRed:0/255.0 green:164/255.0 blue:204/255.0 alpha:1.0];
    [self.forgotPasswordView addSubview:lineView];
    
    UILabel *textFieldTitlelbl=[[UILabel alloc]initWithFrame:CGRectMake(self.forgotPasswordView.center.x-125, lineView.frame.origin.y+10,250, 30)];
    textFieldTitlelbl.textAlignment = NSTextAlignmentCenter;
    textFieldTitlelbl.textColor=[UIColor lightGrayColor];
    [textFieldTitlelbl setFont:[UIFont fontWithName:@"Avenir-Heavy" size:18]];
    textFieldTitlelbl.text=@"Enter your Phone Number";
    [self.forgotPasswordView addSubview:textFieldTitlelbl];
    
    UITextField *forgotPasswordTextF=[[UITextField alloc]initWithFrame:CGRectMake(15, textFieldTitlelbl.frame.origin.y+textFieldTitlelbl.frame.size.height+15,self.forgotPasswordView.frame.size.width-30, 50)];
    forgotPasswordTextF.backgroundColor=[UIColor whiteColor];
    forgotPasswordTextF.layer.borderColor=[UIColor lightGrayColor].CGColor;
    forgotPasswordTextF.layer.borderWidth=1;
    [self.forgotPasswordView addSubview:forgotPasswordTextF];
    
    UIView *buttonsBackV=[[UIView alloc]initWithFrame:CGRectMake(0, self.forgotPasswordView.frame.size.height-50,self.forgotPasswordView.frame.size.width, 70)];
    buttonsBackV.backgroundColor=[UIColor colorWithRed:0/255.0 green:164/255.0 blue:204/255.0 alpha:1.0];
    [self.forgotPasswordView addSubview:buttonsBackV];
    
    UIButton *cancelButton=[[UIButton alloc]initWithFrame:CGRectMake(30,30, 100, 14)];
    [cancelButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    cancelButton.titleLabel.font=[UIFont fontWithName:@"Avenir-light" size:21];
    [cancelButton setTitle:@"CANCEL" forState:UIControlStateNormal];
    [buttonsBackV addSubview: cancelButton];
    [cancelButton addTarget:self action:@selector(cancelForgotView) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *generateButton=[[UIButton alloc]initWithFrame:CGRectMake(buttonsBackV.frame.size.width-145, 30, 110, 14)];
    generateButton.titleLabel.textColor=[UIColor whiteColor];
    [generateButton setTitle:@"GENERATE" forState:UIControlStateNormal];
    generateButton.titleLabel.font=[UIFont fontWithName:@"Avenir-light" size:21];
    [buttonsBackV addSubview: generateButton];
    
    
}

-(void)cancelForgotView{
    
    [self.forgotPasswordView setHidden:YES];
    [self.backgroundView setHidden:YES];
}

-(IBAction)signUp:(id)sender{
    
    
    SignUpViewController* signUpViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SignUpViewController"];
    [self.navigationController pushViewController:signUpViewController animated:YES];
    
}

-(IBAction)logIn:(id)sender{
    
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"UpdateProfileViewController"];
    [self presentViewController:vc animated:NO completion:nil];

    
}

-(IBAction)forgotPassword:(id)sender{
    
    [self.forgotPasswordView setHidden:NO];
    [self.backgroundView setHidden:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
