//
//  SignUpViewController.h
//  MOYA
//
//  Created by Simran on 11/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSArray *cityArray;
@property(nonatomic,strong)UIView *tableViewBackV;
@property(nonatomic,strong)UIView *backgroundView;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)IBOutlet UIButton  *cityButton;
@end
