//
//  SignUpViewController.m
//  MOYA
//
//  Created by Simran on 11/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import "SignUpViewController.h"

@interface SignUpViewController ()

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.backgroundView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    self.backgroundView.backgroundColor=[UIColor blackColor];
    self.backgroundView.alpha=0.7;
    [self.view addSubview:self.backgroundView];
    [self.backgroundView setHidden:YES];
    self.cityArray=[[NSArray alloc]initWithObjects:@"Patiala",@"Ludhiana",@"Zirakpur",@"Chandigarh", nil];
    
   self.tableViewBackV=[[UIView alloc]initWithFrame:CGRectMake(self.view.center.x-100, 100, 200, self.view.frame.size.height-200)];
    
   
    
    self.tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.tableViewBackV.frame.size.width,self.tableViewBackV.frame.size.height-100)];
    [self.view addSubview:_tableViewBackV];
    [self.tableViewBackV addSubview:self.tableView];
    self.tableViewBackV.backgroundColor=[UIColor whiteColor];
    [self.tableViewBackV setHidden:YES];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    
}
-(IBAction)selectCity:(id)sender{
    
    [self.tableViewBackV setHidden:NO];
    [self.backgroundView setHidden:NO];
}

-(IBAction)signIn:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
        return self.cityArray.count;
    
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str;
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (cell==Nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
    }
    
    cell.textLabel.text=[self.cityArray objectAtIndex:indexPath.row];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
        
        
        
    }


@end
