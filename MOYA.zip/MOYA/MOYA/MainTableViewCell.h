//
//  MainTableViewCell.h
//  MOYA
//
//  Created by Simran on 12/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewCell : UITableViewCell
@property(nonatomic,strong)IBOutlet UIButton *minusButton;
@property(nonatomic,strong)IBOutlet UIButton *addButton;

@property(nonatomic,strong)IBOutlet UILabel *titleLbl;
@property(nonatomic,strong)IBOutlet UILabel *perUnitPricelbl;
@property(nonatomic,strong)IBOutlet UILabel *selectedCellTotalPricelbl;

@property(nonatomic,strong)IBOutlet UITextField *noOfUnitsTextF;



@end
