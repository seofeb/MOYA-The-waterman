//
//  LoginViewController.h
//  MOYA
//
//  Created by Simran on 11/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property(nonatomic,strong)UIView *backgroundView;
@property(nonatomic,strong)UIView *forgotPasswordView;
@end
