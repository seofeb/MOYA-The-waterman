//
//  CheckoutViewController.m
//  MOYA
//
//  Created by Simran on 13/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import "CheckoutViewController.h"

@interface CheckoutViewController ()

@end

@implementation CheckoutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.deliveryTimeBackV.layer.borderColor=[UIColor lightGrayColor].CGColor;
    self.deliveryAddressBackV.layer.borderWidth=2;
    self.deliveryAddressBackV.alpha=0.55;
    self.deliveryTimeBackV.alpha=0.55;
}
-(IBAction)back:(id)sender{
    
    //dismiss push
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
