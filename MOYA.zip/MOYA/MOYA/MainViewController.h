//
//  MainViewController.h
//  MOYA
//
//  Created by Simran on 12/02/17.
//  Copyright © 2017 Goteso. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIGestureRecognizerDelegate>

@property(nonatomic,strong)IBOutlet UITableView *tableView;

@property(nonatomic,strong)IBOutlet UIButton *sideBarButton;
@property(nonatomic,strong)UIView *sideBarBackV;
@property(nonatomic,strong)UIView *backgroundView;
@end
